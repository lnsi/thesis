using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("VncSharp")]
[assembly: AssemblyDescription(".NET VNC Client Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("David Humphrey")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("GPL 2")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("1.0.0")]
